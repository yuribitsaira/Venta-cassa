VENTA DE CASA EN BOJACÁ — VERSIÓN ESTÉTICA FINAL

INCLUYE:
- Encabezado elegante como la versión anterior
- Casa visible en grande
- Título al lado de la fotografía
- Galería estética estilo inmobiliaria
- Nombres de las fotografías conservados
- Imágenes informativas en una sección aparte
- Botones de WhatsApp
- Galería ampliable con JavaScript
- Diseño responsive para celular

ARCHIVOS:
- index.html
- styles.css
- script.js
- assets/
- README.txt

PARA NETLIFY:
Sube la carpeta completa, no solo index.html.


AJUSTE FINAL:
- Se restauraron los botones de WhatsApp.
- El mensaje automático para agendar visita sigue funcionando.
- La imagen "Precio de oportunidad / Papeles al día" es solo informativa.
- La imagen NO está conectada a WhatsApp.


ÚLTIMO CAMBIO:
- Se eliminó todo el panel blanco de la portada.
- Se quitaron título grande, ubicación, precio y botones de la portada.
- La foto principal ahora ocupa todo el ancho.
- El WhatsApp del encabezado y el contacto inferior siguen funcionando.
